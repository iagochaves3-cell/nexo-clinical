# Nexo Clinical Knowledge Platform 3.0

Substituição arquitetural do Nexo AI 2.x por uma plataforma de conhecimento clínico estruturado, versionado e auditável.

## Componentes entregues

- Source Registry versionado e validado por esquema.
- Knowledge Platform para recomendações computáveis e registros farmacológicos.
- Clinical Rules Engine determinístico.
- Núcleo de cálculos preservado da versão anterior.
- Roteamento para especialistas clínicos.
- Safety Pipeline com bloqueios críticos.
- Módulos multimodais iniciais: ECG, laboratório e imagem.
- API FastAPI, CLI, Dockerfile e suíte de testes.
- Evals locais com casos de segurança.

## Instalação

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e ".[api,dev,multimodal]"
pytest
nexo-clinical health
nexo-clinical-api
```

A API fica em `http://127.0.0.1:8000`; verifique `/health`.

## Limites clínicos

A plataforma é infraestrutura para suporte à decisão, não substitui validação clínica, protocolos institucionais ou regulamentação. O Source Registry inicial contém fontes estruturantes; diretrizes, protocolos e fármacos individuais devem ser ingeridos por domínio com revisão humana, versionamento e rastreabilidade.
